#include "helpers.h"
#include <stdlib.h>
// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    int avg=0;
    for (int i=0;i<height;i++)
    {
        for (int j=0;j<width;j++)
        {
            avg=(image[i][j].rgbtBlue+image[i][j].rgbtGreen+image[i][j].rgbtRed)/3;
            image[i][j].rgbtBlue=avg;
            image[i][j].rgbtGreen=avg;
            image[i][j].rgbtRed=avg;
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i=0;i<height;i++)
    {
        for (int j=0;j<width;j++)
        {
                    
            int sepiaRed = (int)(.393 * image[i][j].rgbtRed + .769 * image[i][j].rgbtGreen + .189 * image[i][j].rgbtBlue)%255;
            int sepiaGreen = (int)(.349 * image[i][j].rgbtRed + .686 * image[i][j].rgbtGreen + .168 * image[i][j].rgbtBlue)%255;
            int sepiaBlue = (int)(.272 * image[i][j].rgbtRed + .534 * image[i][j].rgbtGreen + .131 * image[i][j].rgbtBlue)%255;
            image[i][j].rgbtBlue=sepiaBlue;
            image[i][j].rgbtGreen=sepiaGreen;
            image[i][j].rgbtRed= sepiaRed;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE t1;
    for (int i=0;i<height;i++)
    {
        for (int j=0;j<width/2;j++)
        {
            t1=image[i][j];
            image[i][j]=image[i][width-j-1];
            image[i][width-j-1]=t1;                        
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{    
    RGBTRIPLE(*image1)[width] = calloc(height, width * sizeof(RGBTRIPLE));
    for(int i=1;i<height-1;i++)
    {
        for (int j=1;j<width-1;j++)
        {
            RGBTRIPLE t;//={0,0,0};
            int s1=0;
            int s2=0;
            int s3=0;
            for (int k=i-1;k<=i+1;k++)
            {
                for (int l=j-1;l<=j+1;l++)
                {
                    s1=(int)s1+(int)image[k][l].rgbtRed;  
                    s2=(int)s2+(int)image[k][l].rgbtBlue;
                    s3=(int)s3+(int)image[k][l].rgbtGreen;                                      
                }
            }
            t.rgbtRed=(int)(s1/9);
            t.rgbtBlue=(int)(s2/9);
            t.rgbtGreen= (int)(s3/9);
           
            image1[i][j].rgbtBlue=t.rgbtBlue;
            image1[i][j].rgbtGreen=t.rgbtGreen;
            image1[i][j].rgbtRed=t.rgbtRed;   
        }
    }
    for(int m=1;m<height-1;m++)
    {
        for (int n=1;n<width-1;n++)
        {
            image[m][n]=image1[m][n];
        }
    }
    return;
}
